# V24 SA gap fill

12 fitted runs; no SA search; HP from V21/V22; models use fixed Paper or reoptimized SA configurations.

Files: holdout_missing_results.csv, holdout_missing_predictions.csv, holdout_missing_mae.png, experiment_manifest.json.
