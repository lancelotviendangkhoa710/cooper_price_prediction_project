# V23 Experimental gap filling

{
  "source_dataset": "/kaggle/input/datasets/lancelot71000/dataset-9-commodities-daily/dataset_9_commodities_daily.csv",
  "sha256": "9580ede12d474c8f990556842d551dac176b3c16b2d6a4bffb7dc41dd54bf600",
  "rows": 2710,
  "dates": [
    "2016-01-13",
    "2026-11-13"
  ],
  "features": [
    "Copper",
    "Aluminium",
    "Tin",
    "WTI"
  ],
  "lookback": 22,
  "horizon": 1,
  "missing_holdout_ratios": [
    0.925,
    0.95
  ],
  "missing_holdout_schemes": [
    "rolling_756",
    "recency_weighted"
  ],
  "holdout_epochs": 100,
  "holdout_patience": 9,
  "sa_hp_from_v22": {
    "units_1": 47,
    "units_2": 127,
    "learning_rate": 5.0478806754686805e-05
  },
  "walk_forward_start_ratio": 0.8,
  "walk_forward_start_date": "2024-10-07",
  "walk_forward_step": 63,
  "walk_forward_seeds": [
    41,
    42,
    43,
    44,
    45
  ],
  "walk_forward_models": [
    "lstm_residual",
    "gru_residual",
    "reopt_sa_lstm"
  ],
  "walk_forward_epochs": 45,
  "walk_forward_patience": 7,
  "walk_forward_method": "origin-refit, full-history expanding; internal tail validation 10%; no future labels at fit time",
  "scope": "WTI-only; selected models only; not an exhaustive matched-budget assessment",
  "part_a_jobs": 20,
  "part_b_fits": 135,
  "framework": "2.21.0"
}

Files: holdout_missing_results.csv, holdout_missing_predictions.csv, holdout_fitted_rankings.csv, wf_fold_metrics.csv, wf_predictions.csv, wf_seed_summary.csv, wf_dm_hac_by_seed.csv.
